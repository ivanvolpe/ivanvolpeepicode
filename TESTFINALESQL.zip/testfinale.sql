create database if not exists esercitazionefinale;
use esercitazionefinale;

-- ecommerce di apparecchiature elettroniche, come tabelle inserirò: Prodotti, Clienti, Ordini,  Dettaglio ordine

CREATE TABLE Clienti (
id_cliente int auto_increment primary key not null,
nome text not null,
cognome text not null,
email varchar(255) not null,
città text not null,
indirizzo varchar(255) not null
);

CREATE TABLE Prodotti (
id_prodotto int auto_increment primary key not null,
nome_prodotto text not null,
disponibilità int, 
prezzo decimal(10, 2)
);

CREATE TABLE Ordini (
Id_ordine int auto_increment primary key,
Data_ordine datetime, 
Prodotto_ordinato varchar(255),
id_utente int,
FOREIGN KEY (id_utente) references Clienti(id_cliente)
);

CREATE TABLE Dettaglio_ordine (
ID_dettaglioordine int auto_increment primary key,
Stato_ordine varchar(255),
Ordine_id int,
Prodotto_id int, 
Stato_spedizione varchar(255),
foreign key (ordine_id) references Ordini(Id_ordine),
foreign key (prodotto_id) references Prodotti(id_prodotto)
);

Insert into Clienti (nome, cognome, email, città, indirizzo)
Values ('Alessio', 'gialli', 'alessiogialli@gmail.com', 'pisa', 'Via verdi 5');

-- Ho effettuato il primo inserimento attraverso l'insert ma poi per comodità li ho inseriti manualmente nella tabella
-- Prima interrogazione: Ordini totali di alessio gialli

SELECT Ordini.*, Prodotti.nome_prodotto
FROM Ordini
JOIN Clienti ON Ordini.id_utente = Clienti.id_cliente
JOIN Dettaglio_ordine ON Ordini.Id_ordine = Dettaglio_ordine.Ordine_id
JOIN Prodotti ON Dettaglio_ordine.Prodotto_id = Prodotti.id_prodotto
WHERE Clienti.nome = 'Alessio' AND Clienti.cognome = 'Gialli';

-- Seconda interrogazione: Clienti che hanno effettuato più ordini

SELECT Clienti.nome, Clienti.cognome, COUNT(Ordini.Id_ordine) AS Numero_ordini
FROM Clienti
LEFT JOIN Ordini ON Clienti.id_cliente = Ordini.id_utente
GROUP BY Clienti.id_cliente
ORDER BY Numero_ordini DESC;

-- Terza interrogazione: Ordini consegnati 

SELECT Ordini.Id_ordine, Ordini.Data_ordine, Clienti.nome, Clienti.cognome, Prodotti.nome_prodotto, Dettaglio_ordine.Stato_spedizione
FROM Ordini
JOIN Clienti ON Ordini.id_utente = Clienti.id_cliente
JOIN Dettaglio_ordine ON Ordini.Id_ordine = Dettaglio_ordine.Ordine_id
JOIN Prodotti ON Dettaglio_ordine.Prodotto_id = Prodotti.id_prodotto
WHERE Dettaglio_ordine.Stato_spedizione = 'consegnato';

-- Quarta interrogazione: Ordini in consegna

SELECT Ordini.Id_ordine, Ordini.Data_ordine, Clienti.nome, Clienti.cognome, Prodotti.nome_prodotto, Dettaglio_ordine.Stato_spedizione
FROM Ordini
JOIN Clienti ON Ordini.id_utente = Clienti.id_cliente
JOIN Dettaglio_ordine ON Ordini.Id_ordine = Dettaglio_ordine.Ordine_id
JOIN Prodotti ON Dettaglio_ordine.Prodotto_id = Prodotti.id_prodotto
WHERE Dettaglio_ordine.Stato_spedizione = 'in consegna';

-- Quinta interrogazione: ordini in magazzino

SELECT Ordini.Id_ordine, Ordini.Data_ordine, Clienti.nome, Clienti.cognome, Prodotti.nome_prodotto, Dettaglio_ordine.Stato_spedizione
FROM Ordini
JOIN Clienti ON Ordini.id_utente = Clienti.id_cliente
JOIN Dettaglio_ordine ON Ordini.Id_ordine = Dettaglio_ordine.Ordine_id
JOIN Prodotti ON Dettaglio_ordine.Prodotto_id = Prodotti.id_prodotto
WHERE Dettaglio_ordine.Stato_spedizione = 'in magazzino';

-- Sesta interrrogazione: nome e cognome di clienti che hanno acquistato un powerbank

SELECT Clienti.nome, Clienti.cognome
FROM Clienti
JOIN Ordini ON Clienti.id_cliente = Ordini.id_utente
JOIN Dettaglio_ordine ON Ordini.Id_ordine = Dettaglio_ordine.Ordine_id
JOIN Prodotti ON Dettaglio_ordine.Prodotto_id = Prodotti.id_prodotto
WHERE Prodotti.nome_prodotto = 'powerbank';

-- Settima interrogazione: nome e cognome di clienti che hanno acquistato uno smartwatch

SELECT Clienti.nome, Clienti.cognome
FROM Clienti
JOIN Ordini ON Clienti.id_cliente = Ordini.id_utente
JOIN Dettaglio_ordine ON Ordini.Id_ordine = Dettaglio_ordine.Ordine_id
JOIN Prodotti ON Dettaglio_ordine.Prodotto_id = Prodotti.id_prodotto
WHERE Prodotti.nome_prodotto = 'smartwatch';

-- Ottava interrogazione: prodotti ordinati da michele rosso 

SELECT Prodotti.nome_prodotto
FROM Prodotti
JOIN Dettaglio_ordine ON Prodotti.id_prodotto = Dettaglio_ordine.Prodotto_id
JOIN Ordini ON Dettaglio_ordine.Ordine_id = Ordini.Id_ordine
JOIN Clienti ON Ordini.id_utente = Clienti.id_cliente
WHERE Clienti.nome = 'michele' AND Clienti.cognome = 'rosso';

-- Nona interrogazione: prodotti ordinati da antonio bianchi 

SELECT Prodotti.nome_prodotto
FROM Prodotti
JOIN Dettaglio_ordine ON Prodotti.id_prodotto = Dettaglio_ordine.Prodotto_id
JOIN Ordini ON Dettaglio_ordine.Ordine_id = Ordini.Id_ordine
JOIN Clienti ON Ordini.id_utente = Clienti.id_cliente
WHERE Clienti.nome = 'antonio' AND Clienti.cognome = 'bianchi';

-- Decima interrogazione: prodotti ordinati da valentina blu

SELECT Prodotti.nome_prodotto
FROM Prodotti
JOIN Dettaglio_ordine ON Prodotti.id_prodotto = Dettaglio_ordine.Prodotto_id
JOIN Ordini ON Dettaglio_ordine.Ordine_id = Ordini.Id_ordine
JOIN Clienti ON Ordini.id_utente = Clienti.id_cliente
WHERE Clienti.nome = 'valentina' AND Clienti.cognome = 'blu';



